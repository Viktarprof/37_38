
//Задание 1:

for(let i = 10; i <= 50; i++){
    if( i % 2 == 0){
        console.log(i);
    }
} 


//Задание 2:
const object = [
    {
    firstName: 'Viktar',
    lastName: 'Kalosha',
    age: 31,
    pupils: true
}
]
for (let i = 0; i < object.length; i++){
const {firstName, lastName, age, pupils} = object[i]
    console.log(` My Name is  ${firstName};  Last name is  ${lastName}; Í have is  ${age}  yaers; I have not a papupils, it is:  ${pupils}. Thank you`);
}



//задание 3
const array = [
    ' я в Симбирск, ',
    ' в трактире. ',
    ' с утра ',
    ' В ту же ночь ',
    ' Я остановился ',
    ' для закупки ', 
    ' что и было поручено Савельичу. ',
    ' приехал, ',
    ' где должен был ',
    ' нужных вещей ',
    ' отправился по лавкам ',
    ' пробыть сутки ',
    ' Савельич '
]
console.log('Your length array = ' + array.length);

for (let i = 0; i < array.length; i++){
console.log(array[i]); // выводит текст в столбик
}


result = array[0] + array[1] + array[2] + array[3] + array[4] + array[5] +  array[6] + array[7] + array[8] + array[9] + array[10] + array[11]+ array[12] + array[13];
    console.log(result)
    //так громоздко и на мой взгляд глупо  



// задание 4
const firstName = 'Viktar';
const lastName = 'Kalosha';
function about(){
    const fullName = `${firstName} ${lastName}`;
    console.log(fullName);
}
about()

function you(firstName, lastName){
    console.log('You : ' + `${firstName} ${lastName}`);
}
you('Viktar', 'Kalosha');



//задание 5
let number1 = 21;
let number2 = 67;

    while (number1 < number2){
        number1 += 2;
        console.log(number1)
    }


