package com.auto.finland;

public class Cars {
    public Cars() {
        System.out.println("Hello from Finland");
    }
}
