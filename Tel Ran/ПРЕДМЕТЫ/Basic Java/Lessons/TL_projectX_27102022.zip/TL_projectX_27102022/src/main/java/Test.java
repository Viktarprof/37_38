public class Test {

    public void printIt() {
        System.out.println("hello");
    }

}
